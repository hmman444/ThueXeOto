package com.hcmute.ltdd.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.hcmute.ltdd.data.repository.AuthRepository;
import com.hcmute.ltdd.model.User;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// Lớp ViewModel quản lý trạng thái đăng nhập
public class AuthViewModel extends ViewModel {


}
