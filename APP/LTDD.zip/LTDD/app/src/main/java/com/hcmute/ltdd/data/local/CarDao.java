package com.hcmute.ltdd.data.local;

public class CarDao {
}
