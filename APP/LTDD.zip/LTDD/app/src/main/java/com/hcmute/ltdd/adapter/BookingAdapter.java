package com.hcmute.ltdd.adapter;

public class BookingAdapter {
}
