package com.hcmute.ltdd.model;

public class Booking {
}
