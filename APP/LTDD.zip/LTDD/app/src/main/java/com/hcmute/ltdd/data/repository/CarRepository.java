package com.hcmute.ltdd.data.repository;

public class CarRepository {
}
