// package com.hcmute.thuexe;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class ThueXeApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
