package com.hcmute.thuexe.model.enums;

public enum MessageStatus {
    SENDING,
    DELIVERED,
    READ
}
