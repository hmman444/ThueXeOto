package com.hcmute.thuexe.model.enums;

public enum CarStatus {
    AVAILABLE,
    BOOKED,
    PENDING,
    MAINTENANCE,
    INACTIVE
}