package com.hcmute.thuexe.model.enums;

public enum MessageType {
    TEXT,
    POST
}
