package com.hcmute.thuexe.repository;

public class AdminRepository {
    
}
